struct personal_data
{
 int id;
 char name[49];
 int score;
};

