struct student{
	char name[20];
	int number;
};
