struct personal_data_format
{
    char name[50];
    char pass[50];
    int score;
};

struct personal_data_format *Data;
int Data_num;

