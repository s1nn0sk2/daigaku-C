#include <stdio.h>
#include "6-7-8rpoland.h"

struct stack Stack_header =
{
	100,
	0,
	NULL
};